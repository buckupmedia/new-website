Symfony Polyfill / Iconv
========================

This component provides a native PHP implementation of the
[php.net/iconv](https://php.net/iconv) functions
(short of [`ob_iconv_handler`](https://php.net/ob-iconv-handler)).

More information can be found in the
[main Polyfill README](https://github.com/symfony/polyfill/blob/master/README.md).

License
=======

This library is released under the [MIT license](LICENSE).
