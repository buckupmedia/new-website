<?php 

/*--------------------*/
// Description: Affilink - Coupons & Deals Php Script
// Author: Wicombit
// Author URI: https://www.wicombit.com
/*--------------------*/
    
require '../../config.php';
require '../functions.php';
require '../views/header.view.php';       
require '../views/error.view.php';    
require '../views/footer.view.php';       

?>